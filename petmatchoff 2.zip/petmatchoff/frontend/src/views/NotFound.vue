<template>
  <div class="container">
    <h2>Page non trouvée</h2>
    <router-link to="/">Retour à l'accueil</router-link>
  </div>
</template>
